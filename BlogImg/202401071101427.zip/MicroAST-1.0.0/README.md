# MicroAST
Official Pytorch code for "MicroAST: Towards Super-Fast Ultra-Resolution Arbitrary Style Transfer" (AAAI 2023)
